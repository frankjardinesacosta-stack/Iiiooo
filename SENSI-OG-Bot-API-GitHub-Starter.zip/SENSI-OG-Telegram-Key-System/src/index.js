require("dotenv").config();

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const express = require("express");
const helmet = require("helmet");
const Database = require("better-sqlite3");
const { Telegraf } = require("telegraf");

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const ADMIN_ID = String(process.env.ADMIN_TELEGRAM_ID || "");
const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.DATABASE_PATH || "./data/sensi-keys.sqlite";

if (!TOKEN || TOKEN === "PASTE_BOTFATHER_TOKEN_HERE") {
  console.error("Falta TELEGRAM_BOT_TOKEN en .env");
  process.exit(1);
}
if (!/^\d+$/.test(ADMIN_ID)) {
  console.error("Falta ADMIN_TELEGRAM_ID: debe ser tu ID personal de Telegram, no el ID del bot.");
  process.exit(1);
}

fs.mkdirSync(path.dirname(path.resolve(DB_PATH)), { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS keys (
    key TEXT PRIMARY KEY,
    created_at INTEGER NOT NULL,
    expires_at INTEGER,
    device_id TEXT,
    revoked INTEGER NOT NULL DEFAULT 0
  );
`);
const insertKey = db.prepare("INSERT INTO keys (key, created_at, expires_at) VALUES (?, ?, ?)");
const getKey = db.prepare("SELECT * FROM keys WHERE key = ?");
const bindDevice = db.prepare("UPDATE keys SET device_id = ? WHERE key = ? AND device_id IS NULL");
const revokeKey = db.prepare("UPDATE keys SET revoked = 1 WHERE key = ?");
const listKeys = db.prepare("SELECT key, created_at, expires_at, device_id, revoked FROM keys ORDER BY created_at DESC LIMIT 30");

function isAdmin(ctx) {
  return String(ctx.from?.id || "") === ADMIN_ID;
}
function makeKey() {
  return "SENSI-" + crypto.randomBytes(12).toString("hex").toUpperCase();
}
function durationMs(kind) {
  return ({ "1d": 86400000, "7d": 7 * 86400000, "30d": 30 * 86400000, "permanent": null })[kind];
}

const bot = new Telegraf(TOKEN);
bot.start((ctx) => ctx.reply(
  "SENSI OG Key Bot\\n\\nComandos de administrador:\\n/newkey 1d\\n/newkey 7d\\n/newkey 30d\\n/newkey permanent\\n/keys\\n/revoke SENSI-...\\n\\nLas keys se validan en tu servidor SENSI OG."
));
bot.command("newkey", (ctx) => {
  if (!isAdmin(ctx)) return ctx.reply("No autorizado.");
  const kind = (ctx.message.text.split(/\s+/)[1] || "").toLowerCase();
  if (!(kind in { "1d": 1, "7d": 1, "30d": 1, "permanent": 1 })) {
    return ctx.reply("Uso: /newkey 1d | 7d | 30d | permanent");
  }
  const now = Date.now();
  const ms = durationMs(kind);
  const key = makeKey();
  insertKey.run(key, now, ms === null ? null : now + ms);
  return ctx.reply(`Key creada:\\n${key}\\nDuración: ${kind}\\n\\nSe vinculará al primer dispositivo que la valide.`);
});
bot.command("keys", (ctx) => {
  if (!isAdmin(ctx)) return ctx.reply("No autorizado.");
  const rows = listKeys.all();
  if (!rows.length) return ctx.reply("Todavía no hay keys.");
  const body = rows.map((r) => {
    const status = r.revoked ? "REVOCADA" : (r.expires_at && r.expires_at <= Date.now() ? "VENCIDA" : "ACTIVA");
    return `${r.key} — ${status} — dispositivo: ${r.device_id || "sin vincular"}`;
  }).join("\\n");
  return ctx.reply(body.slice(0, 3900));
});
bot.command("revoke", (ctx) => {
  if (!isAdmin(ctx)) return ctx.reply("No autorizado.");
  const key = (ctx.message.text.split(/\s+/)[1] || "").trim().toUpperCase();
  if (!key) return ctx.reply("Uso: /revoke SENSI-...");
  const result = revokeKey.run(key);
  return ctx.reply(result.changes ? "Key revocada." : "No encontré esa key.");
});

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "8kb" }));
app.get("/health", (_req, res) => res.json({ ok: true, service: "sensi-og-key-api" }));

// App integration contract: POST /api/public/validate
// JSON body: { "key": "SENSI-...", "device_id": "stable-device-identifier" }
app.post("/api/public/validate", (req, res) => {
  const key = typeof req.body?.key === "string" ? req.body.key.trim().toUpperCase() : "";
  const deviceId = typeof req.body?.device_id === "string" ? req.body.device_id.trim() : "";
  if (!/^SENSI-[A-F0-9]{24}$/.test(key) || deviceId.length < 8 || deviceId.length > 200) {
    return res.status(400).json({ ok: false, error: "invalid_request", message: "La key o el identificador del dispositivo no es válido." });
  }
  const row = getKey.get(key);
  if (!row || row.revoked) {
    return res.status(200).json({ ok: false, error: "invalid_key", message: "La key no existe o fue revocada." });
  }
  if (row.expires_at !== null && row.expires_at <= Date.now()) {
    return res.status(200).json({ ok: false, error: "expired_key", message: "La key ha vencido." });
  }
  if (row.device_id && row.device_id !== deviceId) {
    return res.status(200).json({ ok: false, error: "device_mismatch", message: "La key ya está vinculada a otro dispositivo." });
  }
  if (!row.device_id) bindDevice.run(deviceId, key);
  return res.json({ ok: true, status: "active", expires_at: row.expires_at });
});

app.use((_req, res) => res.status(404).json({ ok: false, error: "not_found" }));
const server = app.listen(PORT, () => console.log(`SENSI OG API escuchando en ${PORT}`));
bot.launch().then(() => console.log("Telegram bot iniciado")).catch((err) => {
  console.error("No se pudo iniciar el bot:", err.message);
  process.exit(1);
});
process.once("SIGINT", () => { bot.stop("SIGINT"); server.close(); db.close(); });
process.once("SIGTERM", () => { bot.stop("SIGTERM"); server.close(); db.close(); });
